---
name: Bug report
about: Report an issue with Ignition
---

# Bug #

## Operating System Version ##

## Ignition Version ##

## Environment ##

What hardware/cloud provider/hypervisor is being used to run Ignition?

## Expected Behavior ##

## Actual Behavior ##

## Reproduction Steps ##

  1. ...
  2. ...

## Other Information ##
