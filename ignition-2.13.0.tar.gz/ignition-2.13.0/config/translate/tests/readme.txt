Tests for this translator are in their own package since it needs to test
translating from one package to another. This pattern should not be replicated
in other places in the codebase
